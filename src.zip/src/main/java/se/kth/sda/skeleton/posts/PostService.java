package se.kth.sda.skeleton.posts;

import java.util.List;
import java.util.Optional;

/*
    @TODO Implement service methods.
 */
public class PostService {
}
